//: Playground - noun: a place where people can play

import UIKit

let unsortedArray = [100,10,15,7,99,23]
 let sorted = unsortedArray.sorted { return $0 < $1 }
print(sorted)


struct Student {
    var rollNo : Int
    var name : String
}

var arrayOfStudents = [Student]()

let student1 = Student(rollNo: 100, name: "Danny")
arrayOfStudents.append(student1)

let student2 = Student(rollNo: 99, name: "John")
arrayOfStudents.append(student2)

let student3 = Student(rollNo: 101, name: "Daniel")
arrayOfStudents.append(student3)

let student4 = Student(rollNo: 98, name: "Laska")
arrayOfStudents.append(student4)


let sortedStudentsByRollNO = arrayOfStudents.sorted { $0.rollNo < $1.rollNo}
print(sortedStudentsByRollNO)
sortedStudentsByRollNO[0]
let sortedStudentsByName = arrayOfStudents.sorted { $0.name < $1.name}
print(sortedStudentsByName)

let dictionary = [ ["rollNo" : 10, "name" : "Daniel"], ["rollNo" : 9, "name" : "Robart"],["rollNo" : 15, "name" : "Harvanak"]]
print(dictionary)
print(dictionary[0]["rollNo"])
let sortedDictArray = dictionary.sorted { let rollNo1 = $0["rollNo"] as! Int;
    let rollNo2 = $1["rollNo"] as! Int;
    return rollNo1 < rollNo2
    
}
print(sortedDictArray)
//dictionary.sorted {   $0["rollNo"] as? Int < $1["rollNo"] as? Int}
    
    
    







var str = "Hello, playground"
let n = 4;


if 1...10 ~= n {
    print("true")
}

let array = [10,11, 12, 14]
//var squareArray : [Int] = []
//
//for number in array {
//    squareArray.append(number*number)
//}
//print(squareArray)

var squareArray = array.map { $0 * $0 }
print(squareArray)

let milesToPoint = ["point1":120.0,"point2":50.0,"point3":70.0]
let kmToPoint = milesToPoint.map { name,miles in miles * 1.6093 }
//let array = [10,11, 12, 14]
let total = array.reduce(0, +)
Double(array.reduce(0, +))/Double(array.count)


let stringsArray = ["abc","def","ghi"]
let combinedString = stringsArray.reduce("",  +)

let names = ["Saikiran","Komirishetty"]
let fullnames = names.reduce("My Name is: ") {text, name in "\(text) \(name)"}
print(fullnames)
let collections = [[1,2,3],[4,5],[6,7,8]]
let flat = collections.flatMap { $0 }
print(flat)
let oddValues = collections.flatMap { $0.filter{ $0 % 2 != 0} }
print(oddValues)
func sum (a a : Int = 0,  b : Int = 0) -> Int {
    return a + b
}
sum(a : 10,b : 20)





// "abcdefghi"
